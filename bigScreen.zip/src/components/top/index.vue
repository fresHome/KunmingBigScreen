<template>
  <div class="index" :style="{img:'top-bg.png'} | imgLoad()">
    <step direction="left" number="15"></step>
    <p>经济运行分析平台</p>
    <step direction="right" number="15"></step>
  </div>
</template>

<script>
import step from './step'

export default {
  name: 'index',
  data () {
    return {}
  },
  components: { step },
  methods: {}
}
</script>

<style lang="scss" scoped>
  .index {
    height: 0.88rem;
    text-align: center;
    box-sizing: border-box;
    padding-top: 0.17rem;
    font-size: 0.32rem;
    color: #fff;
    display: flex;
    justify-content: center;
    align-items: center;

    p {
      width: 8.55rem;
    }
  }
</style>
