module.exports = {
  publicPath: './',
  outputDir: 'dist',
  assetsDir: 'static'
}
