<template>
  <div class="index">
    <box title="经济趋势">
      <chart ref="chart1" :skey="'jjqs'" :option="jjqs"></chart>
    </box>
  </div>
</template>

<script>
import box from '../../public/box'
import tab from '../../public/tab'
import chart from '../../public/charts/echarts/chart'
import { deepClone, convertRem } from '../../utils'

let tooltip = {
  trigger: 'axis',
  confine: true,
  padding: convertRem(0.1),
  textStyle: {
    fontSize: convertRem(0.1),
    lineHeight: convertRem(0.14)
  },
  backgroundColor: 'rgba(41,162,217,0.6)'
}
const allData = {
  jjqs: {
    ys: [[142.79, 98.11, 154.98, 168.79, 181.82, 169.38, 172.63, 171.69], [130.24, 85.77, 141.67, 154.55, 167.82, 157.39, 149.23, 150.38, 162.77, 170.89, 183.86, 164.32]],
    ss: [[18.58, 12.89, 21.14, 21.98, 23.65, 22.02, 22.49, 22.58], [16.93, 11.15, 18.41, 20.09, 21.81, 20.46, 19.39, 19.55, 21.16, 22.26, 23.9, 21.36]]
  },
  cyfz: {
    ys: [
      {
        name: '数字经济',
        y: 521.43
      },
      {
        name: '文化创意',
        y: 335.22
      },
      {
        name: '生物医药',
        y: 89.34
      },
      {
        name: '休闲旅游',
        y: 200.12
      },
      {
        name: '金融科技',
        y: 53.45
      },
      {
        name: '先进装备制造',
        y: 220.47
      },
      {
        name: '现代农业',
        y: 4.38
      }
    ],
    ss: [
      {
        name: '数字经济',
        y: 63.22
      },
      {
        name: '文化创意',
        y: 40.57
      },
      {
        name: '生物医药',
        y: 9.61
      },
      {
        name: '休闲旅游',
        y: 23.02
      },
      {
        name: '金融科技',
        y: 6.95
      },
      {
        name: '先进装备制造',
        y: 28.68
      },
      {
        name: '现代农业',
        y: 0.52
      }
    ]
  },
  srfb: {
    ys: [
      {
        name: '无',
        y: 30.73,
        sliced: true
      },
      {
        name: '(0，500万]',
        y: 46.55,
        sliced: true
      },
      {
        name: '(500万，2000万]',
        y: 16.76,
        sliced: true
      },
      {
        name: '(2000万，2亿]',
        y: 4.58,
        sliced: true
      },
      {
        name: '2亿+',
        y: 1.38,
        sliced: true
      }
    ],
    ss: [
      {
        name: '无',
        y: 32.93,
        sliced: true
      },
      {
        name: '(0，500万]',
        y: 47.88,
        sliced: true
      },
      {
        name: '(500万，2000万]',
        y: 10.94,
        sliced: true
      },
      {
        name: '(2000万，2亿]',
        y: 5.46,
        sliced: true
      },
      {
        name: '2亿+',
        y: 2.79,
        sliced: true
      }
    ]
  }
}
export default {
  name: 'index',
  data () {
    return {
      list: ['ys', 'ss'],
      number: 0,
      interval: null,
      activeJJqs: 'ys',
      jjqs: {
        grid: {
          top: '12%',
          left: '2%',
          right: 0,
          bottom: 0,
          containLabel: true
        },
        tooltip: tooltip,
        legend: {
          top: 'top',
          textStyle: {
            color: '#AAECFF',
            fontSize: 12
          },
          icon: 'line',
          itemWidth: 8,
          itemHeight: 8,
          data: ['今年', '去年']
        },
        xAxis: {
          type: 'category',
          axisLine: {
            show: false
          },
          axisLabel: {
            color: '#8FCEEF',
            interval: 0,
            textStyle: {
              fontSize: '0.07rem'
            }
          },
          axisTick: {
            show: false
          },
          data: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月']
        },
        yAxis: [
          {
            type: 'value',
            axisLine: {
              show: false
            },
            name: '(万)',
            axisLabel: {
              color: '#8FCEEF',
              textStyle: {
                fontSize: '0.07rem'
              }
            },
            splitLine: {
              lineStyle: {
                color: 'rgba(102, 185, 251, 0.24)'
              }
            },
            axisTick: {
              show: false
            }
          }
        ],
        series: [
          {
            type: 'line',
            name: '今年',
            color: '#993EFF',
            smooth: true,
            lineStyle: {
              width: 3 * window.innerWidth / 1920,
              shadowColor: 'rgba(201,255,146,0.2)',
              shadowBlur: 20 * window.innerWidth / 1920,
              color: new this.$echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                offset: 0,
                color: '#993EFF'
              }, {
                offset: 1,
                color: '#E658FF'
              }])
            },
            showSymbol: false,
            data: []
          },
          {
            type: 'line',
            name: '去年',
            color: '#2CACFF',
            smooth: true,
            lineStyle: {
              width: 3 * window.innerWidth / 1920,
              shadowColor: 'rgba(201,255,146,0.2)',
              shadowBlur: 20 * window.innerWidth / 1920,
              color: new this.$echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                offset: 0,
                color: '#2CACFF'
              }, {
                offset: 1,
                color: '#00FCFF'
              }])
            },
            showSymbol: false,
            data: []
          }
        ]
      },
    }
  },
  components: {
    box,
    tab,
    chart,
    pei3d,
    bar3d
  },
  props: ['allCarousel'],
  methods: {
    changeJJqs (type) {
      this.activeJJqs = type
      let newOption = deepClone(this.jjqs)
      newOption.series[0].data = allData.jjqs[type][0]
      newOption.series[1].data = allData.jjqs[type][1]
    },
    changeAll (type) {
      this.changeJJqs(type)
    },
  },
  mounted () {
    this.init()
  }
}
</script>

<style lang="scss" scoped>
  .index {
  }
</style>
