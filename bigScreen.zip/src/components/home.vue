<template>
  <div class="home" :style="{img:'bg.jpg'} | imgLoad()" @mousemove="mousemove">
    <top></top>
    <div class="main">
      <left :allCarousel="allCarousel" class="left"></left>
      <center :allCarousel="allCarousel" class="center"></center>
      <right :allCarousel="allCarousel" class="right"></right>
    </div>
  </div>
</template>

<script>
import top from '../components/top'
import left from '../components/left'
import center from '../components/center'
import right from '../components/right'

export default {
  name: 'home',
  data () {
    return {
      time: 0,
      interval: '',
      allCarousel: null
    }
  },
  components: { top, left, center, right },
  methods: {
    mousemove () {
      this.stopInterval()
    },
    stopInterval () {
      this.allCarousel = 'stop'
      this.time = 0
    },
    startInterval () {
      this.interval = setInterval(() => {
        this.time++
      }, 1000)
      this.time = 0
    }
  },
  watch: {
    time (val) {
      if (val == 10) {
        this.allCarousel = 'go'
      }
    }
  },
  mounted () {
    this.startInterval()
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
  .home {
    width: 100vw;
    height: 100vh;
    overflow: hidden;

    .main {
      height: calc(100vh - 0.88rem);
      box-sizing: border-box;
      display: flex;
      justify-content: space-between;
      padding: 0.18rem;

      .left, .right {
        width: 4.46rem;
      }

      .center {
        flex-grow: 1;
      }
    }
  }
</style>
