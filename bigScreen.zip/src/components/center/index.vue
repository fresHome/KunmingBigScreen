<template>
  <div class="index">
    <list></list>
  </div>
</template>

<script>
import list from './list'

export default {
  name: 'index',
  data () {
    return {}
  },
  components: { list },
  methods: {}
}
</script>

<style lang="scss" scoped>
  .index {

    .map {
      height: 8.58rem;
      position: relative;

      & > div {
        position: absolute;
        bottom: 0;
        left: 50%;
        transform: translate(-50%, 0);
      }

      .circle {
        width: 5rem;
        height: 2.81rem;
        z-index: 1;
      }

      .light {
        width: 7.02rem;
        height: 4.72rem;
        z-index: 1;
      }

      .light2 {
        width: 9.6rem;
        height: 7.87rem;
        bottom: -0.18rem;
        z-index: 1;
      }
    }
  }
</style>
