<template>
  <div class="index" :style="{img:'box-bg.png'} | imgLoad()">
    <p>
      <i :style="{img:'arrow.png'} | imgLoad()"></i>
      <i :style="{img:'arrow.png'} | imgLoad()"></i>
      {{ title }}
    </p>
    <div class="content">
      <slot></slot>
    </div>
  </div>
</template>

<script>
export default {
  name: 'index',
  data () {
    return {}
  },
  props: ['title'],
  methods: {}
}
</script>

<style lang="scss" scoped>
  .index {
    width: 4.46rem;
    height: 2.89rem;

    &:first-child {
      margin-top: 0.1rem;
    }

    p {
      height: 0.3rem;
      line-height: 0.3rem;
      color: #53FFF8;
      font-size: 0.16rem;
      display: flex;
      justify-content: flex-start;
      align-items: center;
      padding-left: 0.23rem;

      i {
        width: 0.11rem;
        height: 0.11rem;
        margin-right: 0.07rem;

        &:first-child {
          margin-right: 0.01rem;
        }
      }
    }

    .content {
      position: relative;
      padding-top: 0.2rem;
    }

    margin-bottom: 0.3rem;
  }
</style>
