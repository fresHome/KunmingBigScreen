import Vue from 'vue'
import App from './App.vue'
import router from './router'
import './utils/rem'
import * as filters from './filters'
import echarts from 'echarts'
import './assets/css/index.scss'
import Highcharts from 'highcharts'
import highcharts3d from 'highcharts/highcharts-3d'
import $ from 'jquery'

window.jQuery = $
Object.keys(filters).forEach(key => {
  Vue.filter(key, filters[key])
})
highcharts3d(Highcharts)
Vue.prototype.$echarts = echarts
Vue.config.productionTip = false

new Vue({
  router,
  render: h => h(App)
}).$mount('#app')
